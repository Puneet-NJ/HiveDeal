export const LOGO =
	"https://seeklogo.com/images/O/opencart-logo-923F11C362-seeklogo.com.png";
